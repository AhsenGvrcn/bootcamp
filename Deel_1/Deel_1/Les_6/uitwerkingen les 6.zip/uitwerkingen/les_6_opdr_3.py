leeftijd = int(input("Wat is je leeftijd?"))

if leeftijd >= 16:
    print("Gefeliciteerd, je mag je brommerrijbewijs halen.")
else:
    print("Helaas, je zult nog even moeten wachten.")