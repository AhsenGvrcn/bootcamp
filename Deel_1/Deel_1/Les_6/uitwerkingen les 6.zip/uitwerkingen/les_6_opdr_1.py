#Tijdens de les kregen we te horen over "if", is een besslissings operator. ( If en else!)
x = 18
if x==18 :
    print('de waarde van x = 18')

