a = 5
b = 8
c = 9
d = 3
e = 1
f = 5

print(a<b)
print(c>d)
print(e>f)
print(c>a)
print(f<d)